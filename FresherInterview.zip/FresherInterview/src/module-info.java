module FresherInterview {
}