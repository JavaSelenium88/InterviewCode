/*
 * Requirement : IBM is the company which hires Developers ,UI Developers , QA & Full stack developers.
 * */

package com.fi.companies;

import com.fi.interviewrounds.Dev_Rounds;
import com.fi.interviewrounds.FullStack;
import com.fi.interviewrounds.QA_rounds;
import com.fi.interviewrounds.UI_Rounds;

public class IBM implements Dev_Rounds, FullStack, QA_rounds, UI_Rounds {  // IBM Hires the UI , fullstack developer & QA so implemented the interfaces

	@Override
	public void UI_round1_Telephone() {
		System.out.println("IBM UI Telephone round");
	}

	@Override
	public void UI_round2_ScriptingLanguage() {
		System.out.println("IBM UI scripting language");
	}

	@Override
	public void UI_round3_WebDesigning() {
		System.out.println("IBM UI web designing");
	}

	@Override
	public void qa_round1_Telephonic() {
		System.out.println("IBM QA Telephonic");
	}

	@Override
	public void qa_round2_Technical() {
		System.out.println("IBM QA Technical");
	}

	@Override
	public void qa_round3_domainKnowledge() {
		System.out.println("IBM QA Domain");
	}

	@Override
	public void devops() {
		System.out.println("IBM devops");
	}

	@Override
	public void dev_round1_Telephonic() {
		System.out.println("IBM dec Telephonic");
	}

	@Override
	public void dev_round2_Programming() {
		System.out.println("IBM dev programming");
	}

	@Override
	public void dev_round3_Logicalskill() {
		System.out.println("IBM dev Logical");
	}

	@Override
	public void communication() {
		System.out.println("IBM Communication");
	}

}
