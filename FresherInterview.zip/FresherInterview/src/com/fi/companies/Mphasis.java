/*
 * Requirement: Maphasis is a consultancy which used to hire QA. As there is no more Mphasis so made the class abstarct.
 * */
package com.fi.companies;

import com.fi.interviewrounds.QA_rounds;

abstract public class Mphasis implements QA_rounds {  // Implemented the QA_rounds as Mphasis hires QA only

	@Override
	public void qa_round1_Telephonic() {
		System.out.println("Mphasis company round1 telephonic 8 out of 10");
	}

	@Override
	public void qa_round2_Technical() {
		System.out.println("Mphasis company round2 technical 9 out of 10");
	}

	@Override
	public void qa_round3_domainKnowledge() {
		System.out.println("Mphasis company round3 domain 9 out of 10");
	}

	@Override
	public void communication() {
		System.out.println("Mphasis communication 500000");
	}
	
	@Override
	public void databaseCheckSql() {
		System.out.println("database 6 out of 10");
	}

}

