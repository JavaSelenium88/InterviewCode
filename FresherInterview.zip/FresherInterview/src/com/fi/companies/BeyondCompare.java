
/* Requirement : Beyond compare is the consultancy which is tied up with big companies and interviews the candidate for the specific profile.
 * 
 * */
package com.fi.companies;

import com.fi.interviewrounds.*;
import com.fi.companies.*;

public class BeyondCompare {
			
		public void conductInterview(QA_rounds qa) {  
		
			if(qa instanceof Dev_Rounds) { 
			((HP)qa).automation_qtp(); // Upcasting to HP and calling the method.
			}
					
		}

	
}
