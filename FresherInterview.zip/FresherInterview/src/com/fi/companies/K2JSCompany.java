package com.fi.companies;

import com.fi.interviewrounds.QA_rounds;

public class K2JSCompany implements QA_rounds {

	@Override
	public void qa_round1_Telephonic() {
		System.out.println("K2js company round1 telephonic 6 out of 10");
	}

	@Override
	public void qa_round2_Technical() {
		System.out.println("K2js company round 2 technical 7 out of 10");
	}

	@Override
	public void qa_round3_domainKnowledge() {
		System.out.println("K2js company round3 BFSI");
	}

	@Override
	public void communication() {
		System.out.println("K2js company round4 communication");
	}

}
