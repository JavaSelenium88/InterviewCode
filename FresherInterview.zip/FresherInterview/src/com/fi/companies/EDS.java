/*
 * EDS Acquired the Mphasis. EDS used to hire for the Development position too. EDS is part of HP so made this class abstract.
 * */
package com.fi.companies;

import com.fi.interviewrounds.Dev_Rounds;

abstract public class EDS extends Mphasis implements Dev_Rounds {

	@Override
	public void dev_round1_Telephonic() {
		System.out.println("EDS round 1 8 out of 10");
	}

	@Override
	public void dev_round2_Programming() {
		System.out.println("EDS Mainframe cobol");
	}

	@Override
	public void dev_round3_Logicalskill() {
		System.out.println("EDS logical 7 out of 10");
	}
	public void communication() {
		System.out.println("EDS increated to 1000000");
	}
	
	@Override
	public void qa_round1_Telephonic() {
		System.out.println("EDS company round1 telephonic 8 out of 10");
	}
	
	abstract void automation_qtp();
}