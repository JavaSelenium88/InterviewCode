/*
 * HP Acquired the EDS and it also hires for the UI development , full stack and some advanced QA position.
 * */
package com.fi.companies;

import com.fi.interviewrounds.Dev_Rounds;
import com.fi.interviewrounds.FullStack;
import com.fi.interviewrounds.QA_rounds;
import com.fi.interviewrounds.UI_Rounds;

public class HP extends EDS implements QA_rounds, Dev_Rounds, UI_Rounds, FullStack {

	@Override
	public void devops() {                      //only unimplemented methods have to be implemented
		System.out.println("HP Devops");
	}

	@Override
	public void UI_round1_Telephone() {
		System.out.println("HP Tele[hone round");
	}

	@Override
	public void UI_round2_ScriptingLanguage() {
		System.out.println("HP scripting language");
	}

	@Override
	public void UI_round3_WebDesigning() {
		System.out.println("HP web design");
	}

	@Override
	public void automation_qtp() {
		System.out.println("HP 9 out of 10 automation");
	}

}

