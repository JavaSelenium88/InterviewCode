/*
 * Requirement : Set of rounds to interview candidate for the UI_ROunds
 * */
package com.fi.interviewrounds;

public interface UI_Rounds {
	
	void UI_round1_Telephone();
	void UI_round2_ScriptingLanguage();
	void UI_round3_WebDesigning();
	void communication();	

}