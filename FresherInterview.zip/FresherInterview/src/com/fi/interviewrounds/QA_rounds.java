/*Requirement : Set of rounds to interview a candidate for QA_ROunds profile.*/
package com.fi.interviewrounds;

public interface QA_rounds {
	
	void qa_round1_Telephonic();
	void qa_round2_Technical();
	void qa_round3_domainKnowledge();
	void communication();
	default void databaseCheckSql() {
		System.out.println("SQL basics 1 out of 10");
	}
}
