/*
 * Requirement : Set of rounds to interview a candidate for development profile.
 * 
 * */
package com.fi.interviewrounds;

public interface Dev_Rounds {
	
	void dev_round1_Telephonic();
	void dev_round2_Programming();
	void dev_round3_Logicalskill();
	void communication();
}

