/*
 * Requirement : Set of rounds to interview a candidate for Fullstack profile.
 * */

package com.fi.interviewrounds;

public interface FullStack extends Dev_Rounds, QA_rounds {
	void devops();
}

