/*
 * Requirement : Candidate intervieing for the K2JS company for the Qa position.
 * */
package com.fi.candidates;

import com.fi.companies.*;

public class Candidate1 {
	public static void main(String[] args) {
		
		K2JSCompany k2js=new K2JSCompany();
		
		k2js.qa_round1_Telephonic();
		k2js.qa_round2_Technical();
		k2js.qa_round3_domainKnowledge();
		k2js.communication();
		k2js.databaseCheckSql();
		
	}

}