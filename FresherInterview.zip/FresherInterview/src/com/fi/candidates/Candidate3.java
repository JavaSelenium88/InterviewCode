/*
 * Requirement : Beyond compare is the consultancy , Beyond compare interviewing the candidates for the HP & K2JS company.
 * */
package com.fi.candidates;

import com.fi.companies.HP;
import com.fi.companies.K2JSCompany;
import com.fi.companies.BeyondCompare;

public class Candidate3 {
	
	public static void main(String[] args) {
		
		HP hp1=new HP();
		// Beyond compare interviewing candidate for the HP , 
		new BeyondCompare().conductInterview(hp1);  
		
		//Beyond compare interviewing candidate for the K2JS company.
		K2JSCompany k2bc=new K2JSCompany();
		new BeyondCompare().conductInterview(k2bc); 
		
	}
}
