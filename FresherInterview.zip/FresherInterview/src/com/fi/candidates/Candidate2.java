/*
 * Requirement: Candidate interviewing directly from HP  for the QA position.
 * */
package com.fi.candidates;

import com.fi.interviewrounds.*;
import com.fi.companies.*;

public class Candidate2 {
	
	public static void main(String[] args) {
		
		QA_rounds hp=new HP(); //upcasting inline by pointing to a parent interface
		hp.qa_round1_Telephonic(); 
		hp.qa_round2_Technical();
		hp.qa_round3_domainKnowledge();
		hp.databaseCheckSql();
		((HP)hp).automation_qtp();
		
	}

}